import matplotlib.pyplot as plt
import numpy as np


def nalozi_meritve(datoteka):
    with open(datoteka) as f:
        meritve = eval(f.readline())
        n = len(meritve)
        for i, x in enumerate(meritve):
            if x == -1:
                n = i
                break
        return meritve[:n]


def narisi_vse(skupni_casi, mnozica):
    meritve = [
        (nalozi_meritve(f"meritve_{tip}_{mnozica}.txt"), tip) for tip in ["semidinamicno", "staticno"]
    ]
    for y, ime in meritve:
        x = list(range(len(y)))
        if skupni_casi:
            kum_graf = np.cumsum(y)
            plt.plot(x, kum_graf, label=f"{ime} (skupno)", alpha=0.5)
        else:
            plt.plot(x, y, label=f"{ime} (po korakih)", alpha=0.5)
    plt.legend()
    plt.title(f"Primerjava časovnih zahtevnosti ({mnozica} množica)")
    plt.xlabel("ponovitve (10 dodajanj na ponovitev)")
    plt.ylabel("čas [ms]")
    plt.tight_layout()
    plt.show()


for m in ["prijazna", "neprijazna"]:
    narisi_vse(True, m)
    narisi_vse(False, m)
